#include <cstring>
#include <fstream>
using namespace std;

int main(int argc, char **argv)
{
	printf ("\n");
	printf ("Multiboot flag tool by Persian Prince for Open Vision information module.\n");
	printf ("\n");
	int multiboot=0;
	char line[128];
	ofstream fileout;
	FILE *mb = fopen("/etc/image-version", "r");
	if (mb)
	{
		while (fgets(line, sizeof(line), mb) != NULL)
		{
			if (strstr(line, "distro=@DISTRO_NAME@") == NULL)
			{
				multiboot=1;
			}
			else
			{
				multiboot=0;
			}
		}
		fclose(mb);
		if(multiboot > 0)
		{
			printf("Multiboot detected!\nDifferent distro name!\n");

			fileout.open("/etc/openvision/multiboot");
			if(fileout.is_open())
			{
				fileout << "1";
				printf("Set multiboot flag to 1 for etc file\n");
			}
		}
		else
		{
			printf("Installed on internal flash, correct distro name.\n");

			fileout.open("/etc/openvision/multiboot");
			if(fileout.is_open())
			{
				fileout << "0";
				printf("Set multiboot flag to 0 for etc file\n");
			}
		}
	}
}
