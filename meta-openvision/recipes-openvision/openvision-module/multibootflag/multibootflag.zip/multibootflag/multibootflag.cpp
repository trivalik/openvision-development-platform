#include <cstring>
#include <fstream>
using namespace std;

int main(int argc, char **argv)
{
	printf ("\n");
	printf ("Multiboot flag tool by Persian Prince for Open Vision module.\n");
	printf ("\n");
	int multiboot=0;
	char line[128];
	FILE *mb = fopen("/etc/image-version", "r");
	if (mb)
	{
		while (fgets(line, sizeof(line), mb) != NULL)
		{
			if (strstr(line, "distro=openvision") == NULL)
			{
				multiboot=1;
			}
			else
			{
				printf("Installed on internal flash, correct distro name.\n");
				multiboot=0;
//				printf("Set multiboot flag to 0\n");
			}
		}
		fclose(mb);
		if(multiboot > 0)
		{
			printf("Multiboot detected! Different distro name.\n");

			ofstream fileout;
			fileout.open("/proc/openvision/multiboot");
			if(fileout.is_open())
			{
				fileout << "1";
				printf("Set multiboot flag to 1\n");
			}
		}
	}
}
